#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct Student{
    string id, name;
    int grades[10], numGrades;
    double average;
};
Student students[100];
int studentCount = 0;
void loadData(){
    ifstream enterdata("students.txt");
    while (enterdata >> students[studentCount].id >> students[studentCount].name >> students[studentCount].numGrades) {
        int total = 0;
        for (int i=0;i<students[studentCount].numGrades;i++) {
            enterdata>>students[studentCount].grades[i];
            total+=students[studentCount].grades[i];
        }
        students[studentCount].average=total/(double)students[studentCount].numGrades;
        studentCount++;
    }
}
void saveData() {
    ofstream outputFile("students.txt");
    for (int i = 0; i < studentCount; i++) {
        outputFile << students[i].id << " " << students[i].name << " " << students[i].numGrades << " ";
        for (int j=0;j<students[i].numGrades;j++) {
            outputFile <<students[i].grades[j]<< " ";
        }
        outputFile <<endl;
    }
}
int main() {
    loadData();
    int choice;
    do {
        cout << "\n1. Add Student\n2. Display All\n3. Exit\nEnter choice: ";
        cin >> choice;
        if (choice ==1 && studentCount<100) {
            cout << "Enter ID, Name, Number of Grades: ";
            cin >> students[studentCount].id >> students[studentCount].name >> students[studentCount].numGrades;
            int total =0;
            for (int i=0;i<students[studentCount].numGrades;i++) {
                cout << "Enter Grade " << i + 1 << ": ";
                cin >> students[studentCount].grades[i];
                total += students[studentCount].grades[i];
            }
            students[studentCount].average = total / (double)students[studentCount].numGrades;
            studentCount++;
            cout << "Student Added\n";
        }
        else if (choice == 2) {
            cout << "ID\tName\tAverage\n";
            for (int i =0;i<studentCount; i++) {
                cout << students[i].id << "\t" << students[i].name << "\t" << students[i].average << "\n";
            }
        }
    } while (choice != 3);
    return 0;
}
